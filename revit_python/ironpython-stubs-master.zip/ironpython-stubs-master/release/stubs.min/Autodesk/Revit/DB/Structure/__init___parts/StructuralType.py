class StructuralType(Enum,IComparable,IFormattable,IConvertible):
 """
 Represents the structural type of a family instance.

 

 enum StructuralType,values: Beam (1),Brace (2),Column (3),Footing (4),NonStructural (0),UnknownFraming (5)
 """
 def __eq__(self,*args):
  """ x.__eq__(y) <==> x==yx.__eq__(y) <==> x==yx.__eq__(y) <==> x==y """
  pass
 def __format__(self,*args):
  """ __format__(formattable: IFormattable,format: str) -> str """
  pass
 def __ge__(self,*args):
  pass
 def __gt__(self,*args):
  pass
 def __init__(self,*args):
  """ x.__init__(...) initializes x; see x.__class__.__doc__ for signaturex.__init__(...) initializes x; see x.__class__.__doc__ for signaturex.__init__(...) initializes x; see x.__class__.__doc__ for signature """
  pass
 def __le__(self,*args):
  pass
 def __lt__(self,*args):
  pass
 def __ne__(self,*args):
  pass
 def __reduce_ex__(self,*args):
  pass
 def __str__(self,*args):
  pass
 Beam=None
 Brace=None
 Column=None
 Footing=None
 NonStructural=None
 UnknownFraming=None
 value__=None

