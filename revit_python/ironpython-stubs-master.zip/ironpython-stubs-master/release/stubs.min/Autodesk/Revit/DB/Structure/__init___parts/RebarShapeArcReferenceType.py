class RebarShapeArcReferenceType(Enum,IComparable,IFormattable,IConvertible):
 """
 A Rebar Shape Definition constraint that is

    measured to a bend must take the bar diameter into

    account by specifying whether it measures to

    the exterior,centerline,or interior of the bend.

 

 enum RebarShapeArcReferenceType,values: Centerline (0),External (1),Internal (-1)
 """
 def __eq__(self,*args):
  """ x.__eq__(y) <==> x==yx.__eq__(y) <==> x==yx.__eq__(y) <==> x==y """
  pass
 def __format__(self,*args):
  """ __format__(formattable: IFormattable,format: str) -> str """
  pass
 def __ge__(self,*args):
  pass
 def __gt__(self,*args):
  pass
 def __init__(self,*args):
  """ x.__init__(...) initializes x; see x.__class__.__doc__ for signaturex.__init__(...) initializes x; see x.__class__.__doc__ for signaturex.__init__(...) initializes x; see x.__class__.__doc__ for signature """
  pass
 def __le__(self,*args):
  pass
 def __lt__(self,*args):
  pass
 def __ne__(self,*args):
  pass
 def __reduce_ex__(self,*args):
  pass
 def __str__(self,*args):
  pass
 Centerline=None
 External=None
 Internal=None
 value__=None

