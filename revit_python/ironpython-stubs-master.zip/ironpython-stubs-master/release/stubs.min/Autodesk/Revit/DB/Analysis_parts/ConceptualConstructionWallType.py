class ConceptualConstructionWallType(Enum,IComparable,IFormattable,IConvertible):
 """
 ConceptualConstructionType values for Walls.

 

 enum ConceptualConstructionWallType,values: HighMassConstructionHighInsulation (5),HighMassConstructionNoInsulationInterior (8),HighMassConstructionTypicalColdClimateInsulation (6),HighMassConstructionTypicalMildClimateInsulation (7),InvalidExteriorWallTypeConstruction (-1),LightweightConstructionHighInsulation (0),LightweightConstructionLowInsulation (3),LightweightConstructionNoInsulationInterior (4),LightweightConstructionTypicalColdClimateInsulation (1),LightweightConstructionTypicalMildClimateInsulation (2),NumWallTypeConstruction (9)
 """
 def __eq__(self,*args):
  """ x.__eq__(y) <==> x==yx.__eq__(y) <==> x==yx.__eq__(y) <==> x==y """
  pass
 def __format__(self,*args):
  """ __format__(formattable: IFormattable,format: str) -> str """
  pass
 def __ge__(self,*args):
  pass
 def __gt__(self,*args):
  pass
 def __init__(self,*args):
  """ x.__init__(...) initializes x; see x.__class__.__doc__ for signaturex.__init__(...) initializes x; see x.__class__.__doc__ for signaturex.__init__(...) initializes x; see x.__class__.__doc__ for signature """
  pass
 def __le__(self,*args):
  pass
 def __lt__(self,*args):
  pass
 def __ne__(self,*args):
  pass
 def __reduce_ex__(self,*args):
  pass
 def __str__(self,*args):
  pass
 HighMassConstructionHighInsulation=None
 HighMassConstructionNoInsulationInterior=None
 HighMassConstructionTypicalColdClimateInsulation=None
 HighMassConstructionTypicalMildClimateInsulation=None
 InvalidExteriorWallTypeConstruction=None
 LightweightConstructionHighInsulation=None
 LightweightConstructionLowInsulation=None
 LightweightConstructionNoInsulationInterior=None
 LightweightConstructionTypicalColdClimateInsulation=None
 LightweightConstructionTypicalMildClimateInsulation=None
 NumWallTypeConstruction=None
 value__=None

